<html>
<head>
	<script>
				var uname = document.getElementById("Username").value;
		        var pwd = document.getElementById("Password").value;
		        if(uname =='')
		        {
			        alert("Please enter user name!")
		        }
		        else if(pwd=='')
		        {
        	        alert("Enter the password!")
		        }
		        else
		        {
	                alert('Thank You!')
                    //Redirecting to other page or webste code or you can set your own html page.
                    //window.location = "profile.html";
                }
	</script>
</head>
</html>